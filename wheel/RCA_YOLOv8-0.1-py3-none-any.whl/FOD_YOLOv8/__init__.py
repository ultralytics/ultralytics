from .custom_detector import CustomPredictor
from .custom_trainer import CustomTrainer

__all__ = [
    "CustomPredictor",
    "CustomTrainer"
]